Calendrier javascript---------------------
Url     : http://codes-sources.commentcamarche.net/source/34725-calendrier-javascriptAuteur  : AnthedDate    : 02/08/2013
Licence :
=========

Ce document intitul� � Calendrier javascript � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

Un fichier js, une feuille de style, quelques images et c'est parti. Il suffit d
'ajouter les quelques div du fichier htm &agrave; votre page et vous aurez un ca
lendrier pratique pour mettre &agrave; jour vos zones de saisie de dates. De nom
breux calendriers existent d&eacute;j&agrave; mais celui-ci a l'avantage de ne p
as &ecirc;tre volumineux (10ko pour le js). Les modifications des images et de l
a feuille de style doivent suffir &agrave; le personnaliser &agrave; votre guise
 (plut&ocirc;t rapide ...).
<br /><a name='conclusion'></a><h2> Conclusion : </
h2>
<br />Cette version est compatible IE / Firefox.
